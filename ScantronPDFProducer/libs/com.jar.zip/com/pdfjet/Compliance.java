package com.pdfjet;

import java.lang.*;


//>>>>pdfjet {
public class Compliance {
    public static final int PDF_A_1B = 1;
}
//<<<<}

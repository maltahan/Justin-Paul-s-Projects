package util;

import java.lang.*;


class Pair {
    String key = null;
    String value = null;
}



using System;


namespace PDFjet.NET {
public class Compliance {
    public const int PDF_A_1B = 1;
}
}   // End of namespace PDFjet.NET

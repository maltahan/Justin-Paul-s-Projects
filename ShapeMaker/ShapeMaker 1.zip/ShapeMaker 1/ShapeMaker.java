public class ShapeMaker {
    private String solidLine(int length) {
        String retern = "";
        for (int i = length; i > 0; i--) {
            if (i == 1) {
                retern = retern + "*";
            } else {
                retern = retern + "* ";
            }
        }
        return retern;      
    }
    
    private String openLine(int length) {
        String retern = "*";
        for (int i = length; i > 0; i--) {
            if (i == 1) {
                retern = retern + " *";
            } else {
                retern = retern + " ";
            }
        }
        return retern;
    }
    
    private String space(int length) {
        String retern = "";
        for (int i = length; i > 0; i--) {
            retern = retern + " ";
        }
        return retern;
    }
        

    public String makeRectangle(int width, int height) {
        String rect = solidLine(width) + "\n";
        for (int i = 0; i < height - 2; i++) {
           rect += openLine(width) + "\n";
        }
        rect += solidLine(width);
        return rect;
     }
   
     public String makeSquare(int side) {
        return makeRectangle(side, side);
     }
     
     public String makeLeftTriangle(int height) {
         String tri = "";
         for (int i = 1; i <= height; i++) {
             if (i == height) {
                 tri = tri + solidLine(i);
             } else {
                 tri = tri + solidLine(i) + "\n";
             }
         }
         return tri;
     }
     
     public String makeRightTriangle(int height) {
         String tri = "";
         for (int i = 1; i <= height; i++) {
             for (int k = height; k > 0; k--) {
                 tri = tri + space(k) + solidLine(i) + "\n";
             }
         }
         return tri;
     }
     
     public String makeHexagon(int side) {
         return "*";
     }
     
     public String makeOctagon(int side) {
         return "*";
     }
     
     public String makeX(int side) {
         return "*";
     }
     
     public String fallingRhombus(int height) {
         String r = "";
         for (int i = 1; i <= height; i++) {
             for (int k = height; k > 0; k--) {
                 r = r + space(k) + solidLine(i) + "\n";
             }
         }
         return r;
     }
     
     public static void main(String[] args) {
         ShapeMaker sm = new ShapeMaker();
         for (int i = 2; i <= 8; i++) {
             // put what you're trying to test here
             System.out.println(sm.makeRectangle(i, i + 1));
         }
     }
}
